#pragma once
#include <Arduino.h>
#include <Romi32U4.h>

class Grabber {
  public:
    void servoSetup();
    void releaseGrabber();
    void activateGrabber();
};
