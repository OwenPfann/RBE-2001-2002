#pragma once
#include <Arduino.h>
#include <wpi-32u4-library.h>
#include "LineSensors.h"
#include <QTRSensors.h>

QTRSensors qtr;

const uint8_t SensorCount = 2;
uint16_t sensorValues[SensorCount];

int tempQTR = 0;

void qtrSetup() {
  qtr.setTypeAnalog();
  qtr.setSensorPins((const uint8_t[]){A0, A1}, SensorCount);
  qtr.setEmitterPin(2);

  for (uint16_t i = 0; i < 400; i++) {
    qtr.calibrate();
  }
}

bool senseLine() {
  tempQTR = (qtr.readLineBlack(A0) + qtr.readLineBlack(A1))/2;
  if (tempQTR > 3000) {  // guessing on this value, also readLineBlack might mean higher values are better(?)
    return true;
  } else {
    return false;
  }
}
