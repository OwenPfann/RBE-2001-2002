#pragma once
#include <Arduino.h>
#include <Romi32U4.h>
//#include <Servo.h>
#include "servo32u4.h"
#include "Grabber.h"

Servo32U4 servo;

const int ServoFeedbackPin = 18;
const int ServoOutputPin = 5;

void servoSetup() {
  servo.Init();
  servo.Attach();
  servo.SetMinMaxUS(900, 2100); // may need to change
  pinMode(ServoFeedbackPin, INPUT);
  pinMode(ServoOutputPin, OUTPUT);
  
}

void releaseGrabber() {
  servo.Write(1800);  // guessing with this value; also try using a servo pin to write to rather than just servo
}

void activateGrabber() {
  servo.Write(900);   // again totally guessing, fine tune these
}
