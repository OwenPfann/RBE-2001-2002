#pragma once
#include <Arduino.h>
#include <Romi32U4.h>

class BlueMotor { 
    public:
        void blueMotorSetup();
        void reset();
        void setEffort(int effort);
        void setEffortWithoutDB(int effort);
        void moveTo(long position);
        long getPosition();
        void sweep();
        static void isr();
        void setEffort(int effort, bool clockwise);
        void setEffortWithoutDB(int effort, bool clockwise);

        int AIN2;
        int AIN1;
        int ENCA;
        int ENCB;

        //static int newValue;
        static int oldValue;
        static int errorCount;
        static int count;

        long oldDegrees = 0.001;
        long currentDegrees = 0.001;
        int timeCount = 0;

        // duty cycle constants are this plus above AIN2 and AIN1
        const int PWMA = 11;
        const int tolerance = 1;

        static constexpr int X = 5;
        static constexpr int encoderArray[4][4] = {
          {0, -1, 1, 5},
          {1, 0, 5, -1},
          {-1, 5, 0, 1},
          {5, 1, -1, 0}
};


    //private:  // should probably comment this out later or move some ints to public something
        void forwards();
        void backwards();
        void stop();
        //static void isr();
        
        //const char X; char encoderArray[4][4];
        /*
        const char X = 5; char encoderArray[4][4] = {
          {0, -1, 1, X},
          {1, 0, X, -1},
          {-1, X, 0, 1},
          {X, 1, -1, 0}
        };*/
};
