#pragma once
#include <Arduino.h>
#include <wpi-32u4-library.h>
#include "IRdecoder.h"

void decoderSetup() {
  
}
