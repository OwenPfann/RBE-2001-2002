#pragma once
#include <Arduino.h>
#include <wpi-32u4-library.h>

class LineSensors {
  public:
    void qtrSetup();
    bool senseLine();
};
