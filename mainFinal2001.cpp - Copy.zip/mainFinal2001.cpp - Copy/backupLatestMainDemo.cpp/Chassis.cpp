#pragma once
#include <Arduino.h>
#include <Romi32U4.h>
#include "Chassis.h"

Romi32U4Motors motors;
Romi32U4Encoders encoders;

const float wheelDiameter = 2.8;
const int CPR = 1440;
const float wheelTrack = 5.75;

void cDriveDistance(float inches) {
    encoders.getCountsAndResetLeft();
    encoders.getCountsAndResetRight();
    motors.setSpeeds(100, 100);
    while (encoders.getCountsLeft() < (CPR/wheelDiameter) * inches && encoders.getCountsRight() < (CPR/wheelDiameter) * inches) {
        delay(1);
    }
    motors.setSpeeds(0, 0);
}

void drive(float speed) {
    motors.setSpeeds(speed, speed);
}

void brake() {
    motors.setSpeeds(0, 0);
}

void turnAngle(float degrees) {
    encoders.getCountsAndResetLeft();
    encoders.getCountsAndResetRight();
    motors.setSpeeds(-50, 50);
    while ((encoders.getCountsRight() - (encoders.getCountsLeft())) < (CPR/wheelDiameter) / (360.0/(wheelTrack*3.14))) {
        delay(1);
    }
}

void startTurn(float degrees) {
    encoders.getCountsAndResetLeft();
    encoders.getCountsAndResetRight();
    if (degrees < 0) {
      motors.setSpeeds(-10, 50);
    } else {
      motors.setSpeeds(50, -10);
    }
}

bool turnComplete() {
    if (encoders.getCountsAndResetLeft() > 89 || 
          encoders.getCountsAndResetLeft < -89 || 
            encoders.getCountsAndResetRight() > 89 || 
              encoders.getCountsAndResetRight < -89) {
      motors.setSpeeds(0, 0);
      encoders.getCountsAndResetLeft();
      encoders.getCountsAndResetRight();
      return true;
    }
    return false;
}
