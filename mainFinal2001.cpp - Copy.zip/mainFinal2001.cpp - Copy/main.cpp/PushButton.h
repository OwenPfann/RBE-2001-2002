/*#pragma once
#include <Arduino.h>
#include <Romi32U4.h>
#include "BlueMotor.h"
#include "Pushbutton.cpp"

class Pushbutton { 
    public:
      bool buttonPushedState();
}*/
