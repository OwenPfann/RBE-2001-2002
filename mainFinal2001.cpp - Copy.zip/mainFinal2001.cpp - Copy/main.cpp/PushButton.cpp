/*#pragma once
#include <Arduino.h>
#include <Romi32U4.h>
#include "bluemotor.h"

Romi32U4ButtonA pb;
//Romi32U4Encoders encoders;

bool buttonPushedState() {
    if (pb.isPressed()) {
        return true;
    } else {
      return false;
    }
}*/
