#pragma once
//#include "Chassis.cpp"
#include <Arduino.h>
#include <Romi32U4.h>

class Chassis { 
    public:
        void cDriveDistance(float inches);
        void turnAngle(float degrees);
        void drive(float speed);
        void brake();
    
    private:
        Romi32U4Motors motors;
        Romi32U4Encoders encoders; 
}; 
