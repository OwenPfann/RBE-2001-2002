#pragma once
#include <Arduino.h>
#include <Romi32U4.h>

class LineSensors {
  public:
    void qtrSetup();
    bool senseLine();
};
