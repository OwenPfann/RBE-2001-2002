#pragma once
#include <Arduino.h>
#include <Romi32U4.h>

class Rangefinder {
  public:
    void rangefinderSetup();
    float getDistanceCM();
    void rfLoop();

    int timeCount = 0;
    const int triggerPin = 12;
    const int echoPin = 0;
};
