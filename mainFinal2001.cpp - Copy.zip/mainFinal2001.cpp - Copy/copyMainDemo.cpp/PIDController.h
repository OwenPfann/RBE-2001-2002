/*#pragma once
#include <Arduino.h>
#include <Romi32U4.h>

class PIDController {
  public:
    PIDController();
    PIDController(float p, float i, float d);
    void setPID(float p, float i, float d);
    float calculate(float currentValue);
    
}
*/
