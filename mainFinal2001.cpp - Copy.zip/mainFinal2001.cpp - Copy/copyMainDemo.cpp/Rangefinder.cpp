#pragma once
#include <Arduino.h>
#include <Romi32U4.h>
#include "Rangefinder.h"

int timeCount = 0;
const int triggerPin = 12;
const int echoPin = 0;

void Rangefinder::rangefinderSetup() {

  pinMode(triggerPin, OUTPUT);
  pinMode(echoPin, INPUT);
}

float Rangefinder::getDistanceCM() {  // gets the pulse distance data
    digitalWrite(triggerPin, LOW);
    delayMicroseconds(2);
    digitalWrite(triggerPin, HIGH);
    delayMicroseconds(10);
    digitalWrite(triggerPin, LOW);

    long echoDuration = pulseIn(echoPin, HIGH);
    float distance = echoDuration * 0.034 / 2.0;
    return distance;
}
