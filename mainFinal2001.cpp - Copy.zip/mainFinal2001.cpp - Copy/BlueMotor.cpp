#pragma once
#include <Arduino.h>
#include <Romi32U4.h>
#include "BlueMotor.h"

Romi32U4ButtonA pb;

// blue motor constants

//const int PWMA = 11;
const int AIN2 = 4;
const int AIN1 = 13;
const int ENCA = 3;
const int ENCB = 2;

int BlueMotor::oldValue = 0;
int BlueMotor::errorCount = 0;
int BlueMotor::count = 0;

// cpp exlusive variables
float velocity = 0;

constexpr int BlueMotor::X;
constexpr int BlueMotor::encoderArray[4][4];

void BlueMotor::isr() {
  int newValue = (digitalRead(3) << 1) | digitalRead(2);
  int value = BlueMotor::encoderArray[BlueMotor::oldValue][newValue];
  //Serial.println("ISR 1");
  if (value == 5){
    BlueMotor::errorCount++;
    //Serial.println("ISR 2");
  } else {
    if (value == 1) {
      BlueMotor::count++;
      //Serial.println("ISR++");
    } else if (value == -1) {
      BlueMotor::count--;
      //Serial.println("ISR--");
    }
  }
  BlueMotor::oldValue = newValue;
}

//Romi32U4Motors motors;
void BlueMotor::blueMotorSetup() {

  AIN2 = 4;
  AIN1 = 13;
  ENCA = 3;
  ENCB = 2;
  //Serial.begin(115200);
  pinMode(PWMA, OUTPUT);
  pinMode(AIN1, OUTPUT);
  pinMode(AIN2, OUTPUT);
  pinMode(ENCA, INPUT);
  pinMode(ENCB, INPUT);

    
  //attachInterrupt(digitalPinToInterrupt(ENCA), isr(), CHANGE);
  //attachInterrupt(digitalPinToInterrupt(ENCB), isr(), CHANGE);
  //pwm setup
  TCCR1A = 0xAB;
  TCCR1B = 0x11;
  ICR1 = 400;
  OCR1C = 0;

  digitalWrite(PWMA, HIGH);
}

void BlueMotor::reset() {
  count = 0;
}

long BlueMotor::getPosition() {
    //return (digitalRead(ENCA) + digitalRead(ENCB))*500*60;
}

void BlueMotor::moveTo(long position) {
  // write later lul
}

void BlueMotor::setEffort(int effort, bool clockwise) {
    //while(pb.isPressed()) {                              // IF NOTHING IS WORKING GET RID OF THE "!"
        if (clockwise) {
            digitalWrite(AIN1, HIGH);
            digitalWrite(AIN2, LOW);
        } else {
            digitalWrite(AIN1, LOW);
            digitalWrite(AIN2, HIGH);
        }
        
        OCR1C = effort;

        unsigned long endtimeCount = millis() + 100;
        timeCount++;
        Serial.print("Position count: ");
        //Serial.println(digitalRead(AIN1));
        Serial.println(count);
        Serial.print("time (ms): ");
        Serial.println(timeCount*100);
        //Serial.println("Hello world, here are some words");
        velocity = (float)count/(timeCount*100)/540*60*1000;//1 rotation per 540 ticks, converting from ticks per ms to rotations per minute
        Serial.print("Angular Velocity: ");
        Serial.println(velocity);

        Serial.print("Effort: ");
        Serial.println(effort);
        
        Serial.println("");     // new line between each reading
        oldDegrees = getPosition();
        
        while (millis() < endtimeCount);
    //}
    digitalWrite(PWMA, LOW);
    OCR1C = 0;
}

void BlueMotor::setEffort(int effort) {
    digitalWrite(PWMA, HIGH);
    if (effort > 0) {
        setEffort(effort, true);
    } else {
        setEffort((-effort), false);
    }
}

void BlueMotor::setEffortWithoutDB(int effort, bool clockwise) {
    //while(pb.isPressed()) {                              // IF NOTHING IS WORKING CHANGE THIS
    if (clockwise) {
      effort += 69; // originally 69
    } else {
      effort += 67; // originally 64
    }
        if (clockwise) {
            digitalWrite(AIN1, HIGH);
            digitalWrite(AIN2, LOW);
        } else {
            digitalWrite(AIN1, LOW);
            digitalWrite(AIN2, HIGH);
        }
        
        OCR1C = effort;

        unsigned long endtimeCount = millis() + 100;
        timeCount++;
        velocity = (float)count/(timeCount*100)/540*60*1000;//1 rotation per 540 ticks, converting from ticks per ms to rotations per minute
        //Serial.print("Position count: ");
        //Serial.println(count);
        Serial.print("time (ms): ");
        Serial.println(timeCount*100);
        Serial.print("Angular Velocity: ");
        Serial.println(velocity);

        Serial.print("Applied effort: ");
        Serial.println(effort);
        if (clockwise) {
          effort -= 69; // originally 69
        } else {
          effort -= 67; // originally 64
        }
        Serial.print("Inputted effort: ");
        Serial.println(effort);
        
        Serial.println("");     // new line between each reading*/
        oldDegrees = getPosition();
        
        while (millis() < endtimeCount);
    //}
    //digitalWrite(PWMA, LOW);
    OCR1C = 0;
}

void BlueMotor::setEffortWithoutDB(int effort) {
    digitalWrite(PWMA, HIGH);
    if (effort > 0) {
      setEffortWithoutDB(effort, true);
    } else {
      effort *= -1;
        setEffortWithoutDB(effort, false);
    }
}

void BlueMotor::forwards() {
    digitalWrite(AIN1, HIGH);
    digitalWrite(AIN2, LOW);
    digitalWrite(PWMA, HIGH);
}

void BlueMotor::backwards() {
    digitalWrite(AIN1, HIGH);
    digitalWrite(AIN2, LOW);
    digitalWrite(PWMA, HIGH);
}

void BlueMotor::stop() {
    digitalWrite(PWMA, LOW);
}

void BlueMotor::sweep() {
    digitalWrite(AIN1, HIGH);
    digitalWrite(AIN2, LOW);
    for (int i = 0; i < 400; i++) {
        OCR1C = i;
        delay(10);
    }
}
